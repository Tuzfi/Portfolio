# Astro Runner: Survival

## Integrantes do grupo

* Gabriel Otávio Assrany Nascimento
* Keven Henrique de Carvalho Lino
* Michael Willian Tang
* Iury Emanuel Alves da Silva

## Descrição do jogo

> Astro Runner: Survival é um jogo de sobrevivência espacial no qual o jogador controla uma nave e precisa permanecer vivo o máximo de tempo possível. Durante a partida, asteroides e naves inimigas surgem constantemente, aumentando o nível de dificuldade. A cada 60 segundos de sobrevivência, o jogador pode escolher uma melhoria para fortalecer sua nave e continuar enfrentando os desafios do espaço.

## Objetivo do jogador

> O objetivo é sobreviver o maior tempo possível, desviando de obstáculos, derrotando inimigos e aprimorando a nave através das melhorias disponíveis ao longo da partida.

## Regras do jogo

* O jogador controla uma nave espacial.
* Asteroides e inimigos aparecem continuamente na tela.
* Colisões ou ataques inimigos causam dano à nave.
* A cada 60 segundos o jogador recebe uma opção de melhoria.
* O jogo termina quando a vida da nave chega a zero.
* O tempo sobrevivido representa a pontuação do jogador.

## Controles

* Mouse movimenta o jogador
* Botão Direito do Mouse: Disparo
* ESC: pausar jogo