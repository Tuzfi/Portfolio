#======= IMPORTAÇÃO DE BIBLIOTECAS =======
import random
import sys
import asyncio

import pygame

from src.assets import carregar_sprites
from src.config import ALTURA, FPS, LARGURA
from src.entities import criar_inimigo, criar_jogador, criar_tiro
from src.gameover import game_over_screen
from src.hud import desenhar_hud
from src.menu import menu
from src.pause import pause_screen
from src.recorde import carregar_recorde, salvar_recorde
from src.render import (
    desenhar_fundo,
    desenhar_inimigos,
    desenhar_nave,
    desenhar_particulas,
    desenhar_tiros,
)
from src.systems import (
    atualizar_movimento_inimigos,
    atualizar_particulas,
    atualizar_tiros,
    atualizar_waves,
    checar_colisao_jogador,
    colisao_tiros,
)


#======= FUNÇÃO PRINCIPAL DO JOGO =======
def executar_jogo():
    #======= INIT PYGAME =======
    pygame.init()
    tela = pygame.display.set_mode((LARGURA, ALTURA))
    pygame.display.set_caption("Astro Runner Survival")
    relogio = pygame.time.Clock()

    #======= FONTES =======
    fonte = pygame.font.SysFont(None, 42)
    fonte_grande = pygame.font.SysFont(None, 90)

    #======= CARREGAMENTO DE SPRITES =======
    nave, inimigo_img, tiro_img = carregar_sprites()

    #======= BACKGROUND =======
    estrelas = [
        [random.randint(0, LARGURA), random.randint(0, ALTURA), random.randint(1, 3)]
        for _ in range(150)
    ]

    #======= RECORDE =======
    recorde = carregar_recorde()

    async def loop_principal():
        nonlocal recorde

        #======= LOOP PRINCIPAL DO JOGO =======
        while True:
            #======= MENU =======
            menu(tela, relogio, fonte, fonte_grande, nave, estrelas, recorde)
            pygame.event.clear()

            #======= RESET DA PARTIDA =======
            jogador = criar_jogador()
            tiros = []
            inimigos = []
            particulas = []

            pontuacao = 0
            wave = 1
            alvo_wave = 5
            spawnados = 0

            cooldown = 0
            dano_timer = 0
            flash_dano = 0
            vida_flash = 0

            jogando = True
            voltar_ao_menu = False

            #======= LOOP DA PARTIDA =======
            while jogando:
                relogio.tick(FPS)
                mx, my = pygame.mouse.get_pos()

                #======= INPUT =======
                for evento in pygame.event.get():
                    if evento.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()

                    if evento.type == pygame.KEYDOWN:
                        if evento.key == pygame.K_ESCAPE:
                            resultado = pause_screen(
                                tela,
                                relogio,
                                fonte,
                                fonte_grande,
                                nave,
                                estrelas,
                            )
                            if resultado == "menu":
                                voltar_ao_menu = True
                                jogando = False
                                break

                    if (
                        evento.type == pygame.MOUSEBUTTONDOWN
                        and evento.button == 3
                        and cooldown <= 0
                    ):
                        tiros.append(criar_tiro(jogador, mx, my))
                        cooldown = 12

                if voltar_ao_menu:
                    pygame.event.clear()
                    break

                #======= MOVIMENTO DO JOGADOR =======
                jogador["x"] += (mx - jogador["x"]) * 0.12
                jogador["y"] += (my - jogador["y"]) * 0.12

                #======= TIMERS =======
                if cooldown > 0:
                    cooldown -= 1
                if dano_timer > 0:
                    dano_timer -= 1
                if flash_dano > 0:
                    flash_dano -= 1
                if vida_flash > 0:
                    vida_flash -= 1

                #======= SPAWN DE INIMIGOS =======
                while spawnados < alvo_wave:
                    inimigos.append(criar_inimigo(wave))
                    spawnados += 1

                #======= SISTEMAS DE JOGO =======
                atualizar_tiros(tiros)
                atualizar_particulas(particulas)
                atualizar_movimento_inimigos(inimigos, jogador)

                if checar_colisao_jogador(inimigos, jogador, dano_timer):
                    vida_flash = 24
                    jogador["vida"] -= 1
                    dano_timer = 60
                    flash_dano = 60

                    if jogador["vida"] <= 0:
                        jogando = False

                pontuacao += colisao_tiros(tiros, inimigos, particulas)

                if atualizar_waves(spawnados, alvo_wave, inimigos):
                    wave += 1
                    alvo_wave += 3
                    spawnados = 0

                #======= RECORDE =======
                if pontuacao > recorde:
                    recorde = pontuacao
                    salvar_recorde(recorde)

                #======= RENDERIZAÇÃO DAS CENAS =======
                tela.fill((5, 5, 15))
                desenhar_fundo(tela, estrelas)
                desenhar_nave(tela, nave, jogador, mx, my, flash_dano)
                desenhar_tiros(tela, tiros, tiro_img)
                desenhar_inimigos(tela, inimigos, inimigo_img)
                desenhar_particulas(tela, particulas)

                progresso = max(0, spawnados - len(inimigos))
                percentual = progresso / alvo_wave
                desenhar_hud(
                    tela, jogador, wave, pontuacao, fonte, percentual, vida_flash
                )
                pygame.display.flip()
                await asyncio.sleep(0)

            if voltar_ao_menu:
                continue

            #======= GAME OVER =======
            game_over_screen(
                tela,
                relogio,
                fonte,
                fonte_grande,
                inimigo_img,
                pontuacao,
                recorde,
                wave,
                estrelas,
            )

    asyncio.run(loop_principal())
